package com.example.educationalloan.repository;

public interface LoginRepository {

}
