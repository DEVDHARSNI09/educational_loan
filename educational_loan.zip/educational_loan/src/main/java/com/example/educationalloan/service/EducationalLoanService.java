package com.example.educationalloan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.educationalloan.model.LoanApplicationModel;
import com.example.educationalloan.model.UserModel;
import com.example.educationalloan.repository.LoanApplicationRepository;
import com.example.educationalloan.repository.UserRepository;

@Service
public class EducationalLoanService {
	@Autowired
	LoanApplicationRepository r;
	public List<LoanApplicationModel> getAllvalues()
	{
		return r.findAll();
		
	}
	public LoanApplicationModel savevalues(LoanApplicationModel s)
	{
		
		return r.save(s);
		
	}
	public String deletevalues(int LoanId)
	{
		r.deleteById(LoanId);
		return "Id has been deleted";
	}
	public LoanApplicationModel getvalues(int LoanId)
	{
		return r.findById(LoanId).get();
	}
	public LoanApplicationModel updateloan(LoanApplicationModel p)
	{
		return r.save(p);
		
	}
	//
	@Autowired
	UserRepository a;
	public List<UserModel> getAlluser()
	{
		return a.findAll();
		
	}
	public String deleteuser(int Id)
	{
		a.deleteById(Id);
		return "Id has been deleted";
	}
	public UserModel saveData(UserModel s)
	{
		
		return a.save(s);
		
	}
	public UserModel updateuser(UserModel p)
	{
		return a.save(p);
		
	}
}

